// إعداد Firebase
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// تهيئة Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

// وظيفة التسجيل
function signUp() {
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;

  auth.createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert('Sign Up Successful!');
      redirectToDashboard();
    })
    .catch((error) => {
      alert(error.message);
    });
}

// وظيفة تسجيل الدخول
function login() {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  auth.signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert('Login Successful!');
      redirectToDashboard();
    })
    .catch((error) => {
      alert(error.message);
    });
}

// وظيفة تسجيل الخروج
function logout() {
  auth.signOut()
    .then(() => {
      alert('Logout Successful!');
      window.location.href = 'index.html'; // العودة إلى صفحة تسجيل الدخول
    })
    .catch((error) => {
      alert(error.message);
    });
}

// الانتقال إلى صفحة المستخدم
function redirectToDashboard() {
  document.querySelector(".container").style.display = "none";
  document.querySelector("#user-section").style.display = "block";
  document.getElementById("user-email").innerText = "البريد الإلكتروني: " + auth.currentUser.email;
}
  position: sticky;
  top: 0;
}

.navbar h1 {
  font-size: 1.5em;
  margin: 0;
}

.navbar button {
  background: #ff758c;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 10px 15px;
  cursor: pointer;
}

.navbar button:hover {
  background: #ff6075;
}

main {
  margin-top: 20px;
  width: 100%;
  max-width: 600px;
  padding: 20px;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 8px;
  box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.2);
  color: #333;
}

.posts {
  margin-top: 20px;
}

.post {
  margin-top: 15px;
  padding: 15px;
  background: #f4f4f4;
  border-radius: 8px;
  text-align: left;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
}

.post h4 {
  margin: 0 0 5px 0;
  color: #2575fc;
}

.post p {
  margin: 0;
}
      alert('Sign Up Successful!');
      showUserSection(userCredential.user);
    })
    .catch((error) => {
      alert(error.message);
    });
}

// وظيفة تسجيل الدخول
function login() {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  auth.signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert('Login Successful!');
      showUserSection(userCredential.user);
    })
    .catch((error) => {
      alert(error.message);
    });
}

// وظيفة تسجيل الخروج
function logout() {
  auth.signOut()
    .then(() => {
      alert('Logout Successful!');
      document.getElementById('auth-section').style.display = 'block';
      document.getElementById('user-section').style.display = 'none';
    })
    .catch((error) => {
      alert(error.message);
    });
}

// عرض قسم المستخدم
function showUserSection(user) {
  document.getElementById('auth-section').style.display = 'none';
  document.getElementById('user-section').style.display = 'block';
  document.getElementById('user-email').innerText = user.email;
}